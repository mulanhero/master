// namespaces.h

namespace mycode {
  
  void foo();

}
