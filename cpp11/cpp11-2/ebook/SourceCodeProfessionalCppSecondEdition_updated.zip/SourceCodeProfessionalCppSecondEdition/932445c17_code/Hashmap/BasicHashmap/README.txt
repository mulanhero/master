Include only TestHashmap.cpp in your project.
