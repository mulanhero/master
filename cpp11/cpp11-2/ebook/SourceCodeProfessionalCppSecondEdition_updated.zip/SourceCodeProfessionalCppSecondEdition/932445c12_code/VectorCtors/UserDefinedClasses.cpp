#include <vector>
using namespace std;

class Element
{
public:
  Element() {}
  virtual ~Element() {}
};

int main()
{
  vector<Element> elementVector;
  return 0;
}
