// Element.h

class Element
{
protected:
	int mValue;
};