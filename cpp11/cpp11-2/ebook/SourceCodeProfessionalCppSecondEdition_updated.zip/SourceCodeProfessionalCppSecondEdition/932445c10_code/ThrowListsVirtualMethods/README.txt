Compile each of the source files in this directory separately.

Notes:
Broken.cpp does not compile on compilers that implement throw lists.
Some compilers (such as Microsoft Visual Studio) fail to implement throw
lists.

