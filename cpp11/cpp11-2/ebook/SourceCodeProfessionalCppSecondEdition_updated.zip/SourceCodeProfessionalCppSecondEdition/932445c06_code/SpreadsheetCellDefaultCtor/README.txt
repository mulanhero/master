Three source files in this directory include implementations of the
SpreadsheetCell class methods. Your project should include
SpreadsheetCellTest.cpp and one of SpreadsheetCell.cpp,
SpreadsheetCellInitList.cpp, or SpreadsheetCellInitListBackward.cpp

