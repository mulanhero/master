Compile each of the source files in this directory separately.

Note: ConstCast.cpp will give a linker error.