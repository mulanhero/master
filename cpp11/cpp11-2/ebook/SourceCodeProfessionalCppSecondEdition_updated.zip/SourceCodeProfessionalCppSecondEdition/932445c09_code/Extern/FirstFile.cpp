// FirstFile.cpp
#include <iostream>
using namespace std;

extern int x;

int main()
{
  cout << x << endl;
}
