// FirstFile.cpp

void f();

int main()
{
  f();
  return 0;
}
