// AnotherFile.cpp
#include <iostream>
using namespace std;

namespace {
  void f();

  void f()
  {
    cout << "f\n";
  }
}
